
<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

$sheetDBColMap = array( "System ID" => "system_id",
                            "Resource Manager"=> "resource_manager", 
                            "Functional Manager"=> "functional_manager" ,
                            "Project" => "project",
                            "Activity Name" => "activity_name",
                            "Role" => "resource_role",
                            "Planned Units" => "planned_units",
                            "Resource ID" => "resource_id",
                            "Resource Name" => "resource_name",
                            "Spreadsheet Field" => "spreadsheet_feild");
?>
