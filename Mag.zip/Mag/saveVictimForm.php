<?php
 require_once 'classes/saveVictims.class.php';
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
$obj = new saveVictims();
$obj->saveVictim();
echo "Thanks";
?>
